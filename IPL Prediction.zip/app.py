import pandas as pd
import numpy as np
from flask import Flask, request, jsonify
from sklearn.model_selection import train_test_split, StratifiedKFold
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
from xgboost import XGBClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.svm import SVC
from sklearn.metrics import accuracy_score
from sklearn.preprocessing import StandardScaler, LabelEncoder
import pickle
import os
import warnings

warnings.filterwarnings('ignore')

app = Flask(__name__)

# ================================
# 📚 Load Datasets
# ================================

matches_df = pd.read_csv('D:/WebiSoftTech/ML_MINI_PROJECTS/IPL Prediction(DC,LSG)/IPL Matches 2008-2023.csv', low_memory=False)
balls_df = pd.read_csv('D:/WebiSoftTech/ML_MINI_PROJECTS/IPL Prediction(DC,LSG)/IPl Ball-by-Ball 2008-2023.csv', low_memory=False)

# Preprocessing
matches_df.columns = matches_df.columns.str.strip()
balls_df.columns = balls_df.columns.str.strip()

# ================================
# 📊 Feature Engineering
# ================================

def add_features(df):
    df['venue_encoded'] = pd.factorize(df['venue'])[0]
    df['toss_decision_encoded'] = pd.factorize(df['toss_decision'])[0]
    df['team1_encoded'] = pd.factorize(df['team1'])[0]
    df['team2_encoded'] = pd.factorize(df['team2'])[0]
    return df

matches_df = add_features(matches_df)

# ================================
# 🔮 Model Training with Best Model Selection
# ================================

def train_best_model(X, y):
    models = {
        'LogisticRegression': LogisticRegression(max_iter=1000, class_weight='balanced'),
        'RandomForest': RandomForestClassifier(n_estimators=500, max_depth=25, random_state=42),
        'GradientBoosting': GradientBoostingClassifier(n_estimators=300, learning_rate=0.03, max_depth=8),
        'XGBoost': XGBClassifier(use_label_encoder=False, eval_metric='logloss', n_estimators=300, learning_rate=0.03, max_depth=8),
        'SVM': SVC(probability=True, kernel='rbf', C=1.5)
    }

    best_model = None
    best_score = 0

    skf = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)
    for name, model in models.items():
        scores = []
        for train_idx, test_idx in skf.split(X, y):
            X_train, X_test = X[train_idx], X[test_idx]
            y_train, y_test = y[train_idx], y[test_idx]
            model.fit(X_train, y_train)
            y_pred = model.predict(X_test)
            score = accuracy_score(y_test, y_pred)
            scores.append(score)
        avg_score = np.mean(scores)
        print(f"✅ Model {name} achieved score: {round(avg_score * 100, 2)}%")

        if avg_score > best_score:
            best_score = avg_score
            best_model = model

    if best_model:
        print(f"🏆 Best Model Selected: {best_model.__class__.__name__} with Score: {round(best_score * 100, 2)}%")
    else:
        print("⚠️ No valid model was trained!")

    return best_model

# ================================
# 🎯 Model Training for Specific Teams
# ================================

def prepare_models(team_name):
    team_matches = matches_df[(matches_df['team1'] == team_name) | (matches_df['team2'] == team_name)]

    # Toss Winning Model
    toss_X = team_matches[['venue_encoded', 'toss_decision_encoded']].values
    toss_y = (team_matches['toss_winner'] == team_name).astype(int).values

    if len(toss_X) > 0:
        toss_model = train_best_model(toss_X, toss_y)
        pickle.dump(toss_model, open(f'models/{team_name.lower().replace(" ", "_")}_toss_model.pkl', 'wb'))

    # Stadium Performance Model
    stadium_df = team_matches[team_matches['venue'] == 'Arun Jaitley Stadium']
    stadium_X = stadium_df[['team1_encoded', 'team2_encoded', 'toss_decision_encoded']].values
    stadium_y = (stadium_df['winner'] == team_name).astype(int).values

    if len(stadium_X) > 0:
        stadium_model = train_best_model(stadium_X, stadium_y)
        pickle.dump(stadium_model, open(f'models/{team_name.lower().replace(" ", "_")}_stadium_model.pkl', 'wb'))

# ================================
# 📡 API Endpoints for Predictions
# ================================

def load_model(team_name, model_type):
    model_path = f'models/{team_name.lower().replace(" ", "_")}_{model_type}_model.pkl'
    if os.path.exists(model_path):
        return pickle.load(open(model_path, 'rb'))
    else:
        return None

@app.route('/predict_toss', methods=['POST'])
def predict_toss():
    data = request.json
    team_name = data['team_name']
    venue_encoded = pd.factorize([data['venue']])[0][0]
    toss_decision_encoded = pd.factorize([data['toss_decision']])[0][0]

    model = load_model(team_name, 'toss')
    if not model:
        return jsonify({"error": f"Model for {team_name} toss prediction not found. Train the model first."}), 404

    X_input = np.array([[venue_encoded, toss_decision_encoded]])
    prediction = model.predict_proba(X_input)[:, 1][0] * 100
    return jsonify({
        "team_name": team_name,
        "toss_win_probability": round(prediction, 2)
    })

@app.route('/predict_stadium_performance', methods=['POST'])
def predict_stadium_performance():
    data = request.json
    team_name = data['team_name']
    team1_encoded = pd.factorize([data['team1']])[0][0]
    team2_encoded = pd.factorize([data['team2']])[0][0]
    toss_decision_encoded = pd.factorize([data['toss_decision']])[0][0]

    model = load_model(team_name, 'stadium')
    if not model:
        return jsonify({"error": f"Model for {team_name} stadium performance not found. Train the model first."}), 404

    X_input = np.array([[team1_encoded, team2_encoded, toss_decision_encoded]])
    prediction = model.predict_proba(X_input)[:, 1][0] * 100
    return jsonify({
        "team_name": team_name,
        "stadium_win_probability": round(prediction, 2)
    })

# ================================
# 🚀 Run Flask Application
# ================================

if __name__ == '__main__':
    if not os.path.exists('models'):
        os.makedirs('models')
    
    # Retrain models for Delhi Capitals and Lucknow Super Giants
    prepare_models('Delhi Capitals')
    prepare_models('Lucknow Super Giants')

    app.run(debug=True)
